﻿

public enum EnumGun
{
    Show = 1,
    Fire,
   hide

}