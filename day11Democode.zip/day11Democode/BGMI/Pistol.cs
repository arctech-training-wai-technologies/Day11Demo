﻿class Pistol : IWeapon
{
  
    public void hide()
    {
        Console.WriteLine("Pistol Hide");

    }
    public void Shoot()
    {
        Console.WriteLine("Pistol Fire............");

    }
    public void Show()
    {
        Console.WriteLine("Show Pistol");

    }

}
