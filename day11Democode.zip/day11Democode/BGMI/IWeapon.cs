﻿ interface IWeapon
{
   public void hide();
    public void Shoot();
    public void Show();
}