﻿
class Rocketlauncher : IWeapon
{
    public void hide()
    {
        Console.WriteLine("Show Rocket launcher ready to launch");
    }

    public void Shoot()
    {
        Console.WriteLine(" Whoosh Boom");
    }

    public void Show()
    {
        Console.WriteLine(" hide Rocket launcher ");
    }
}
