﻿

interface Imenu
{

    void show(IWeapon imenuClick);


}