﻿
//menu M416 = new menu();
//M416.show();
using day11Democode;
Draw draw = new();
draw.Start();
namespace day11Democode
{
    class Draw
    {
        ICanvas[] canvases =
            {
                new Building("Building"),
                new Paper ("Paper"),
                new Plane ("plain"),
                new T_Shirt ( "T - Shirt"),
                new Train ("Train")
            };
        public void Start()
        {
            IDrawTool selectedDrawTool = DrawToolFactory.Create();
            ICanvas selectedCanvas = CanvasFactory.Create();
            do
            {
                // Console.Clear();
                Console.WriteLine("\nDraw Menu");
                Console.WriteLine("Change Surface, (1.Building, 2.Paper, 3.Train, 4.Plane, 5.T.Shirt");
                Console.WriteLine("Change Tool, (b.Brush, r.Roller, p.Pencil, n.Pen");
                Console.WriteLine("d.Draw");
                Console.WriteLine("u.Undo");
                Console.Write("Select a choice: ");
                var keyInfo = Console.ReadKey();
                if (keyInfo.KeyChar >= 'a' && keyInfo.KeyChar <= 'z')
                {
                    if (keyInfo.KeyChar != 'd' && keyInfo.KeyChar != 'u')
                    {
                        selectedDrawTool = DrawToolFactory.Create(keyInfo.KeyChar);
                    }
                }
                else if (keyInfo.KeyChar >= '1' && keyInfo.KeyChar <= '5')

                    selectedCanvas = CanvasFactory.Create(keyInfo.KeyChar);

                switch (keyInfo.KeyChar)
                {
                    case 'd':
                        selectedCanvas.Draw(selectedDrawTool);
                        break;
                    case 'u':
                        selectedCanvas.Undo();
                        break;

                }

            } while (true);

        }
    }

    interface ICanvas
    {
        public void Draw(IDrawTool drawTool);
        public void Undo();

    }
    interface IDrawTool
    {
        public void Drawaltools();
    }

    class CanvasFactory
    {

        public static ICanvas Create(char key = '1')
        {
            switch (key)
            {

                case '1':
                    return new Building("Building");

                case '2':
                    return new Paper("Paper");

                case '3':
                    return new Train("Train");

                case '4':
                    return new Plane("Plane");

                case '5':
                    return new T_Shirt("T_Shirt");

            }

            return null;

        }
    }

    class DrawToolFactory
    {
        public static IDrawTool Create(char key = 'b')
        {

            switch (key)
            {
                case 'b':
                    return new brush("Brush");

                case 'r':
                    return new Roller("Brush");
                case 'p':
                    return new Pencil("Pencil");
                case 'n':
                    return new pen("pen");
            }
            return null;
        }


    }


    class Canvas : ICanvas
    {


        public void Draw(IDrawTool drawTool)
        {
           
        }

        public void Undo()
        {

        }
    }
}

#region"Object"

class Building : ICanvas
{
    string Name;

    public Building(string name)
    {
        Name = name;
    }

    public void Draw(IDrawTool drawTool)
    {
        Console.BackgroundColor = ConsoleColor.Blue;
        Console.WriteLine($"\n{Name} Drawing using {drawTool}");
        Console.ResetColor();
    }

    public void Undo()
    {

    }
}

class Paper : ICanvas
{
    string Name;

    public Paper(string name)
    {
        Name = name;
    }

    public void Draw(IDrawTool drawTool)
    {
        Console.BackgroundColor = ConsoleColor.Blue;
        Console.WriteLine($"\n{Name} Drawing using {drawTool}");
        Console.ResetColor();
    }

    public void Undo()
    {

    }
}
class Train : ICanvas
{
    string Name;

    public Train(string name)
    {
        Name = name;
    }

    public void Draw(IDrawTool drawTool)
    {
        Console.BackgroundColor = ConsoleColor.Blue;
        Console.WriteLine($"\n{Name} Drawing using {drawTool}");
        Console.ResetColor();
    }

    public void Undo()
    {

    }
}
class Plane : ICanvas
{
    string Name;

    public Plane(string name)
    {
        Name = name;
    }

    public void Draw(IDrawTool drawTool)
    {
        Console.BackgroundColor = ConsoleColor.Blue;
        Console.WriteLine($"\n{Name} Drawing using {drawTool}");
        Console.ResetColor();
    }

    public void Undo()
    {

    }
}
class T_Shirt : ICanvas
{

    string Name;

    public T_Shirt(string name)
    {
        Name = name;
    }

    public void Draw(IDrawTool drawTool)
    {
        Console.BackgroundColor = ConsoleColor.Blue;
        Console.WriteLine($"\n{Name} Drawing using {drawTool}");
        Console.ResetColor();
    }

    public void Undo()
    {

    }
}
#endregion
#region" Tools"
class brush : IDrawTool
{
    string IDrawTool = "Brush";

    public brush(string iDrawTool)
    {
        IDrawTool = iDrawTool;
    }

    public void Drawaltools()
    {

    }
}


class pen : IDrawTool
{
    string name;

    public pen(string name)
    {
        this.name = name;
    }

    public void Drawaltools()
    {

    }
}

class Roller : IDrawTool
{
    string name;

    public Roller(string name)
    {
        this.name = name;
    }
    public void Drawaltools()
    {

    }
}

class Pencil : IDrawTool
{
    string name;

    public Pencil(string name)
    {
        this.name = name;
    }
    public void Drawaltools()
    {

    }
}





#endregion



