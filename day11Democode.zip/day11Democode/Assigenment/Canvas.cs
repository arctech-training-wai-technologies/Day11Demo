﻿internal class Canvas
{
    private object p;

    public Canvas(object p)
    {
        this.p = p;
    }
}